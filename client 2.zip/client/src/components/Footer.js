import React from "react"

const Footer = () => {
    return (
        <footer>
            <p class="Footer">Made by Brian Yin and Nathan Hu</p>
        </footer>
    )
}

export default Footer;