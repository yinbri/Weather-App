import React from 'react';

const Header = () => {
    return (
        <>
            {/* <NavBar/> */}
        </>
    )
}

export default Header;



